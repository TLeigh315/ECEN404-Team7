package com.fmn.samuel.forgetmenot;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class DisplayMessageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_message);

        Intent intent = getIntent();
        String name = intent.getStringExtra(Userinput.Name);
        String number = intent.getStringExtra(Userinput.Number);
        String dob = intent.getStringExtra(Userinput.DOB);
        String emergnumber = intent.getStringExtra(Userinput.EMN);
        String makemod = intent.getStringExtra(Userinput.MakeMod);
        String color = intent.getStringExtra(Userinput.Color);
        String license = intent.getStringExtra(Userinput.License);


        TextView textView = findViewById(R.id.textView);
        TextView textView2 = findViewById(R.id.textView2);
        TextView textView3 = findViewById(R.id.textView3);
        TextView textView29 = findViewById(R.id.textView29);
        TextView textView34 = findViewById(R.id.textView34);
        TextView textView32 = findViewById(R.id.textView32);
        TextView textView36 = findViewById(R.id.textView36);
        textView.setText(name);
        textView2.setText(number);
        textView3.setText(dob);
        textView29.setText(emergnumber);
        textView34.setText(makemod);
        textView32.setText(color);
        textView36.setText(license);

    }
}
