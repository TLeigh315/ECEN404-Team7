package com.fmn.samuel.forgetmenot;

import android.content.SharedPreferences;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Sensors extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensors);

        sensorupdate();

    }

    private final int SECONDS = 1000;
    final Handler handler = new Handler();
    public void sensorupdate() {
        final SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        handler.postDelayed(new Runnable() {
            public void run() {

                TextView temp = findViewById(R.id.textView19);
                TextView accel = findViewById(R.id.textView20);
                TextView IR = findViewById(R.id.textView22);
                TextView reed1 = findViewById(R.id.textView23);
                TextView reed2 = findViewById(R.id.textView25);

                final String Temp = pref.getString("Temp", "n/a");
                final String Accel = pref.getString("Accel", "n/a");
                final String Cam = pref.getString("IR", "n/a");
                final String Reed1 = pref.getString("Reed1", "n/a");
                final String Reed2 = pref.getString("Reed2", "n/a");

                temp.setText(Temp);
                accel.setText(Accel);
                IR.setText(Cam);
                reed1.setText(Reed1);
                reed2.setText(Reed2);

                handler.postDelayed(this, SECONDS);
            }
        }, SECONDS);
    }

}
