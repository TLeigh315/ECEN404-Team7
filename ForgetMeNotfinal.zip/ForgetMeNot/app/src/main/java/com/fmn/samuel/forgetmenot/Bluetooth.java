package com.fmn.samuel.forgetmenot;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.support.annotation.MainThread;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Set;

import app.akexorcist.bluetotohspp.library.BluetoothSPP;
import app.akexorcist.bluetotohspp.library.BluetoothState;

public class Bluetooth extends Service {

    private static final String TAG = "BT TEST";

    BluetoothSPP bluetooth = new BluetoothSPP(this);


    Button connect;

    static final int REQUEST_ENABLE_BT = 1;
    BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    int count = 0;
    int start = 0;



    //@Override
    public void onCreate() {//Bundle savedInstanceState) {
     //   super.onCreate(savedInstanceState);
     //   setContentView(R.layout.activity_bluetooth);

        if (!bluetooth.isBluetoothEnabled()) {
            bluetooth.enable();
        } else {
            if (!bluetooth.isServiceAvailable()) {
                bluetooth.setupService();
                bluetooth.startService(BluetoothState.DEVICE_OTHER);
            }
        }

        final SharedPreferences pref =
                PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        if (mBluetoothAdapter == null) {
            AlertDialog.Builder dlgAlert  = new AlertDialog.Builder(this);

            dlgAlert.setMessage("Bluetooth Not Supported");
            dlgAlert.setTitle("Error Message...");
            dlgAlert.setPositiveButton("OK", null);
            dlgAlert.setCancelable(true);
            dlgAlert.create().show();

            dlgAlert.setPositiveButton("Ok",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
        }
        else {
            if (!mBluetoothAdapter.isEnabled()) {
                bluetooth.enable();
             //   Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
             //   startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
            Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();
      //      ListView pairlist = findViewById(R.id.pair_list);
            if (pairedDevices.size() > 0) {
                ArrayList<String> deviceID = new ArrayList<>();
                for (BluetoothDevice device : pairedDevices) {
                    deviceID.add(device.getName());
                }
                ArrayAdapter<String> listadapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, deviceID);
        //        pairlist.setAdapter(listadapter);
            }
        }

      //  bluetooth = new BluetoothSPP(this);

     //   connect = findViewById(R.id.connect);

     //   if (!bluetooth.isBluetoothAvailable()) {
     //       Toast.makeText(getApplicationContext(), "Bluetooth is not available", Toast.LENGTH_SHORT).show();
     //       finish();
     //   }

        bluetooth.setBluetoothConnectionListener(new BluetoothSPP.BluetoothConnectionListener() {
            public void onDeviceConnected(String name, String address) {
               // connect.setText("Connected to " + name);

                final String Username = pref.getString("Name", "n/a");
                final String number = pref.getString("Number", "n/a");
                final String dob = pref.getString("DOB", "n/a");
                final String emergnumber = pref.getString("EMN", "n/a");
                final String makemod = pref.getString("MakeMod", "n/a");
                final String color = pref.getString("Color", "n/a");
                final String license = pref.getString("License", "n/a");
                scheduleSendLocation();
            //    bluetooth.send(Username, true);
                bluetooth.send("P" + number, true);
            //    bluetooth.send(dob, true);
                bluetooth.send("B" + emergnumber, true);
                bluetooth.send("T" + makemod, true);
                bluetooth.send("C" + color, true);
                bluetooth.send("H" + license, true);
                bluetooth.send("R1", true);
            }

            public void onDeviceDisconnected() {
              //  connect.setText("Connection lost");
              //  scheduleSendLocation();
                bluetooth.connect("5C:F3:70:89:9D:D9");
                WarningNotification.notify(getApplicationContext(), "Don't leave your baby!", 0);

              /*  new Thread(new Runnable() {
                    public void run() {
                        while (true) {
                            if (bluetooth.getServiceState() != BluetoothState.STATE_CONNECTED) {
                                bluetooth.connect("5C:F3:70:89:9D:D9");
                            }
                            else {
                                break;
                            }
                        }
                        return;
                    }
                }).start(); */


               // while (true) {
               //     if (bluetooth.getServiceState() != BluetoothState.STATE_CONNECTED) {
               //         bluetooth.connect("5C:F3:70:89:9D:D9");
               //     }
               // }
            }

            public void onDeviceConnectionFailed() {
                //connect.setText("Unable to connect");
                bluetooth.connect("5C:F3:70:89:9D:D9");
               // scheduleSendLocation();


            }

        });

        bluetooth.connect("5C:F3:70:89:9D:D9");
        startService(new Intent(this,GPSloc.class));
        scheduleSendLocation();

     /*   connect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (bluetooth.getServiceState() == BluetoothState.STATE_CONNECTED) {
                    bluetooth.disconnect();
                } else {
                    Intent intent = new Intent(getApplicationContext(), DeviceList.class);
                    startActivityForResult(intent, BluetoothState.REQUEST_CONNECT_DEVICE);
                }
            }
        }); */

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId)
    {
        Log.e(TAG, "onStartCommand");
        super.onStartCommand(intent, flags, startId);
        return START_STICKY;
    }


/*
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == RESULT_CANCELED) {
                AlertDialog.Builder dlgAlert  = new AlertDialog.Builder(this);

                dlgAlert.setMessage("Bluetooth Not Enabled");
                dlgAlert.setTitle("Error Message...");
                dlgAlert.setPositiveButton("OK", null);
                dlgAlert.setCancelable(true);
                dlgAlert.create().show();

                dlgAlert.setPositiveButton("Ok",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });
            }
            else {
                AlertDialog.Builder dlgAlert  = new AlertDialog.Builder(this);

                dlgAlert.setMessage("Bluetooth Enabled and Ready");
                dlgAlert.setTitle("Message");
                dlgAlert.setPositiveButton("OK", null);
                dlgAlert.setCancelable(true);
                dlgAlert.create().show();

                dlgAlert.setPositiveButton("Ok",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });


            }
        }


        if (requestCode == BluetoothState.REQUEST_CONNECT_DEVICE) {
            if (resultCode == Activity.RESULT_OK)
                bluetooth.connect(data);
        } else if (requestCode == BluetoothState.REQUEST_ENABLE_BT) {
            if (resultCode == Activity.RESULT_OK) {
                bluetooth.setupService();
            } else {
                Toast.makeText(getApplicationContext()
                        , "Bluetooth was not enabled."
                        , Toast.LENGTH_SHORT).show();
                finish();
            }
        }


        bluetooth.setOnDataReceivedListener(new BluetoothSPP.OnDataReceivedListener() {
            final SharedPreferences pref =
                    PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
            final SharedPreferences.Editor edit = pref.edit();
            public void onDataReceived(byte[] data, String message) {
                Log.e(TAG,"Message : " + message);

                for (int i = 0; i < message.length()-1; i++) {
                    if (message.charAt(i+1) != ' ') {
                        if (message.charAt(i) == ' ') {
                            start = i+1;
                        }
                    }
                    else if (message.charAt(i+1) != ' ') {

                    } else {
                        if (i-start > 0) {
                            String msg = message.substring(start, i+1);

                            if (msg.charAt(0) == 'T') {
                                edit.putString("Temp", msg.substring(1,msg.length()));
                                edit.apply();
                            } else if (msg.charAt(0) == 'A') {
                                edit.putString("Accel", msg.substring(1,msg.length()));
                                edit.apply();
                            } else if (msg.charAt(0) == 'I') {
                                edit.putString("IR", msg.substring(1,msg.length()));
                                edit.apply();
                            } else if (msg.charAt(0) == 'R') {
                                edit.putString("Reed1", msg.substring(1,msg.length()));
                                edit.apply();
                            } else if (msg.charAt(0) == 'B') {
                                edit.putString("Reed2", msg.substring(1,msg.length()));
                                edit.apply();
                            }
                        }
                    }
                }


            }
        });


    } */

/*
    public void onStart() {
        super.onStart();
        if (!bluetooth.isBluetoothEnabled()) {
            bluetooth.enable();
        } else {
            if (!bluetooth.isServiceAvailable()) {
                bluetooth.setupService();
                bluetooth.startService(BluetoothState.DEVICE_OTHER);
            }
        }
      //  autoConnect("raspberrypi");
    } */



    /*@Override
    public void onPause() {
        super.onPause();

    } */


  //  private final BroadcastReceiver mReceiver = new BroadcastReceiver() {
    //  //      public void onReceive(Context context, Intent intent) {
    //  //          String action = intent.getAction();
    //  //          if (BluetoothDevice.ACTION_FOUND.equals(action)) {
    //  //              BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
    //  //              String deviceName = device.getName();
    //  //              String deviceHardwareAddress = device.getAddress(); // MAC address
    //  //          }
  //      }
  //  };

  //  @Override
  //  protected void onDestroy() {
  //      super.onDestroy();
      //  unregisterReceiver(mReceiver);
       // bluetooth.stopService();

       // startService(new Intent(this,BT_auto.class));
//    }
       double getDouble(final SharedPreferences prefs, final String key, final double defaultValue) {
           return Double.longBitsToDouble(prefs.getLong(key, Double.doubleToLongBits(defaultValue)));
       }

    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                Log.i ("isMyServiceRunning?", true+"");
                return true;
            }
        }
        Log.i ("isMyServiceRunning?", false+"");
        return false;
    }




    private final int SECONDS = 5000;
    final Handler handler = new Handler();
    public void scheduleSendLocation() {
        final SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        handler.postDelayed(new Runnable() {
            public void run() {

                if (bluetooth.getServiceState() != BluetoothState.STATE_CONNECTED) {
                    bluetooth.connect("5C:F3:70:89:9D:D9");
                }
                else {

                    if (!isMyServiceRunning(GPSloc.class)) {
                        startService(new Intent(Bluetooth.this,GPSloc.class));
                    }

                    final double lat = getDouble(pref, "Latitude", 0);
                    final String latitude = Double.toString(lat);

                    final double longit = getDouble(pref, "Longitude", 0);
                    final String longitude = Double.toString(longit);

                    bluetooth.send("A" + latitude, true);
                    bluetooth.send("O" + longitude, true);


                    if (Userinput.sendinfo == 1) {
                        final String Username = pref.getString("Name", "n/a");
                        final String number = pref.getString("Number", "n/a");
                        final String dob = pref.getString("DOB", "n/a");
                        final String emergnumber = pref.getString("EMN", "n/a");
                        final String makemod = pref.getString("MakeMod", "n/a");
                        final String color = pref.getString("Color", "n/a");
                        final String license = pref.getString("License", "n/a");
                        //    bluetooth.send(Username, true);
                        bluetooth.send("P" + number, true);
                        //    bluetooth.send(dob, true);
                        bluetooth.send("B" + emergnumber, true);
                        bluetooth.send("T" + makemod, true);
                        bluetooth.send("C" + color, true);
                        bluetooth.send("H" + license, true);

                        Userinput.sendinfo = 0;
                    }


                    handler.postDelayed(this, SECONDS);
                }
            }
        }, SECONDS);
    }

    private static void sleep(int t) {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Magic here
            }
        }, t); // Millisecond 1000 = 1 sec
    }


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
