package com.fmn.samuel.forgetmenot;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Userinput extends AppCompatActivity {
    public static final String Name = "com.fmn.samuel.forgetmenot.Name";
    public static final String Number = "com.fmn.samuel.forgetmenot.Number";
    public static final String DOB = "com.fmn.samuel.forgetmenot.DOB";
    public static final String EMN = "com.fmn.samuel.forgetmenot.EMN";
    public static final String MakeMod = "com.fmn.samuel.forgetmenot.MakeMod";
    public static final String Color = "com.fmn.samuel.forgetmenot.Color";
    public static final String License = "com.fmn.samuel.forgetmenot.License";
    static int sendinfo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_input);


        final Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View button) {
                Intent intent = new Intent(Userinput.this, DisplayMessageActivity.class);
                EditText ET = findViewById(R.id.editText);
                EditText ET2 = findViewById(R.id.editText2);
                EditText ET3 = findViewById(R.id.editText3);
                EditText ET5 = findViewById(R.id.editText5);
                EditText ET6 = findViewById(R.id.editText6);
                EditText ET7 = findViewById(R.id.editText7);
                EditText ET4 = findViewById(R.id.editText4);
                String name = ET.getText().toString();
                intent.putExtra(Name, name);
                String number = ET2.getText().toString();
                intent.putExtra(Number, number);
                String dob = ET3.getText().toString();
                intent.putExtra(DOB, dob);
                String emergnumber = ET5.getText().toString();
                intent.putExtra(EMN, emergnumber);
                String makemod = ET6.getText().toString();
                intent.putExtra(MakeMod, makemod);
                String color = ET7.getText().toString();
                intent.putExtra(Color, color);
                String license = ET4.getText().toString();
                intent.putExtra(License, license);

                SharedPreferences pref =
                        PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                SharedPreferences.Editor edit = pref.edit();
                edit.putString("Name", ET.getText().toString());
                edit.putString("Number", ET2.getText().toString());
                edit.putString("DOB", ET3.getText().toString());
                edit.putString("EMN", ET5.getText().toString());
                edit.putString("MakeMod", ET6.getText().toString());
                edit.putString("Color", ET7.getText().toString());
                edit.putString("License", ET4.getText().toString());
                edit.apply();

                sendinfo = 1;

                startActivity(intent);

            }
        });

    }

}
